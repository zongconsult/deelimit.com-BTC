<?php
	error_reporting(0);
	require 'security.php';
	if ($db = new mysqli("127.0.0.1","root","AdminHQ18@2013","mailing_list")){

		//echo "Success";


	}else $db->error();
	
	
	?>